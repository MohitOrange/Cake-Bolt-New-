import React from 'react';
import { Heart, Users, Award, Clock } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: <Heart className="h-8 w-8 text-pink-500" />,
      title: "Made with Love",
      description: "Every cake is crafted with passion and attention to detail"
    },
    {
      icon: <Users className="h-8 w-8 text-pink-500" />,
      title: "Family Recipe",
      description: "Traditional recipes passed down through generations"
    },
    {
      icon: <Award className="h-8 w-8 text-pink-500" />,
      title: "Premium Quality",
      description: "Only the finest ingredients from trusted suppliers"
    },
    {
      icon: <Clock className="h-8 w-8 text-pink-500" />,
      title: "Fresh Daily",
      description: "Baked fresh every morning for optimal taste and quality"
    }
  ];

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">About Us</h2>
          <div className="w-24 h-1 bg-pink-500 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Since 1995, Sweet Dreams has been creating magical moments through our artisanal cakes. 
            What started as a small family bakery has grown into a beloved destination for life's 
            sweetest celebrations.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h3>
            <p className="text-gray-600 mb-4">
              Founded by Maria and Giuseppe Rossi, Sweet Dreams began with a simple mission: 
              to bring joy to people's lives through exceptional cakes. Using recipes from 
              Maria's grandmother in Tuscany, we've maintained the same commitment to quality 
              and craftsmanship for nearly three decades.
            </p>
            <p className="text-gray-600 mb-6">
              Today, our team of skilled bakers continues this tradition, creating custom 
              cakes for weddings, birthdays, and all of life's special moments. Every cake 
              tells a story, and we're honored to be part of yours.
            </p>
            <div className="flex items-center space-x-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-pink-600">28+</div>
                <div className="text-gray-600">Years Experience</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-pink-600">15K+</div>
                <div className="text-gray-600">Happy Customers</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-pink-600">500+</div>
                <div className="text-gray-600">Custom Designs</div>
              </div>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/6254025/pexels-photo-6254025.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Baker decorating a cake"
              className="rounded-lg shadow-2xl"
            />
            <div className="absolute -bottom-6 -left-6 bg-pink-600 text-white p-6 rounded-lg shadow-lg">
              <div className="text-2xl font-bold">100%</div>
              <div className="text-sm">Satisfaction Guaranteed</div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center group">
              <div className="bg-white rounded-full p-6 shadow-lg inline-block mb-4 group-hover:shadow-xl transition-shadow duration-300">
                {feature.icon}
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h4>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;