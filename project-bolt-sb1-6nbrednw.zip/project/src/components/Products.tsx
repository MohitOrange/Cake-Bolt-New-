import React, { useState } from 'react';
import { Star, ShoppingCart, Eye } from 'lucide-react';

const Products = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProduct, setSelectedProduct] = useState(null);

  const categories = [
    { id: 'all', name: 'All Products' },
    { id: 'wedding', name: 'Wedding Cakes' },
    { id: 'birthday', name: 'Birthday Cakes' },
    { id: 'cupcakes', name: 'Cupcakes' },
    { id: 'specialty', name: 'Specialty Cakes' }
  ];

  const products = [
    {
      id: 1,
      name: "Elegant Wedding Cake",
      category: "wedding",
      price: "$299",
      image: "https://images.pexels.com/photos/265711/pexels-photo-265711.jpeg?auto=compress&cs=tinysrgb&w=600",
      rating: 5,
      description: "Three-tier vanilla cake with buttercream roses and elegant pearl details",
      features: ["Serves 30-40", "Custom decorations", "Multiple flavors available"]
    },
    {
      id: 2,
      name: "Chocolate Birthday Cake",
      category: "birthday",
      price: "$45",
      image: "https://images.pexels.com/photos/1070850/pexels-photo-1070850.jpeg?auto=compress&cs=tinysrgb&w=600",
      rating: 5,
      description: "Rich chocolate cake with chocolate ganache and colorful decorations",
      features: ["Serves 8-10", "Personalized message", "Candles included"]
    },
    {
      id: 3,
      name: "Rainbow Cupcakes",
      category: "cupcakes",
      price: "$36",
      image: "https://images.pexels.com/photos/1055271/pexels-photo-1055271.jpeg?auto=compress&cs=tinysrgb&w=600",
      rating: 4,
      description: "Dozen colorful cupcakes with vanilla buttercream frosting",
      features: ["12 pieces", "Various flavors", "Perfect for parties"]
    },
    {
      id: 4,
      name: "Red Velvet Layer Cake",
      category: "specialty",
      price: "$65",
      image: "https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=600",
      rating: 5,
      description: "Classic red velvet with cream cheese frosting and elegant presentation",
      features: ["Serves 12-15", "Premium ingredients", "Signature recipe"]
    },
    {
      id: 5,
      name: "Unicorn Birthday Cake",
      category: "birthday",
      price: "$75",
      image: "https://images.pexels.com/photos/1721942/pexels-photo-1721942.jpeg?auto=compress&cs=tinysrgb&w=600",
      rating: 5,
      description: "Magical unicorn-themed cake with pastel colors and edible decorations",
      features: ["Serves 10-12", "Edible glitter", "Custom unicorn horn"]
    },
    {
      id: 6,
      name: "Luxury Wedding Tower",
      category: "wedding",
      price: "$599",
      image: "https://images.pexels.com/photos/1721932/pexels-photo-1721932.jpeg?auto=compress&cs=tinysrgb&w=600",
      rating: 5,
      description: "Five-tier masterpiece with intricate sugar flowers and gold accents",
      features: ["Serves 80-100", "Sugar flowers", "Gold leaf details"]
    },
    {
      id: 7,
      name: "Gourmet Cupcake Selection",
      category: "cupcakes",
      price: "$48",
      image: "https://images.pexels.com/photos/1126359/pexels-photo-1126359.jpeg?auto=compress&cs=tinysrgb&w=600",
      rating: 4,
      description: "Assorted gourmet cupcakes with premium toppings and fillings",
      features: ["12 pieces", "6 different flavors", "Elegant presentation"]
    },
    {
      id: 8,
      name: "Chocolate Decadence",
      category: "specialty",
      price: "$85",
      image: "https://images.pexels.com/photos/1126728/pexels-photo-1126728.jpeg?auto=compress&cs=tinysrgb&w=600",
      rating: 5,
      description: "Ultimate chocolate lovers' cake with multiple chocolate layers",
      features: ["Serves 15-18", "Triple chocolate", "Chocolate decorations"]
    }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  return (
    <section id="products" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Our Products</h2>
          <div className="w-24 h-1 bg-pink-500 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover our exquisite collection of handcrafted cakes, each designed to make 
            your special occasions unforgettable.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                selectedCategory === category.id
                  ? 'bg-pink-600 text-white shadow-lg transform scale-105'
                  : 'bg-gray-100 text-gray-700 hover:bg-pink-100 hover:text-pink-600'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredProducts.map((product) => (
            <div key={product.id} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="relative overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center">
                  <button
                    onClick={() => setSelectedProduct(product)}
                    className="bg-white text-gray-900 px-4 py-2 rounded-full font-semibold opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 flex items-center space-x-2"
                  >
                    <Eye className="h-4 w-4" />
                    <span>View Details</span>
                  </button>
                </div>
                <div className="absolute top-4 right-4 bg-pink-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                  {product.price}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
                <div className="flex items-center mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < product.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                      }`}
                    />
                  ))}
                  <span className="ml-2 text-sm text-gray-600">({product.rating}.0)</span>
                </div>
                <p className="text-gray-600 mb-4 line-clamp-2">{product.description}</p>
                <button className="w-full bg-pink-600 hover:bg-pink-700 text-white py-3 rounded-full font-semibold transition-colors duration-300 flex items-center justify-center space-x-2">
                  <ShoppingCart className="h-4 w-4" />
                  <span>Add to Cart</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Product Modal */}
        {selectedProduct && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="relative">
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="absolute top-4 right-4 bg-white rounded-full p-2 shadow-lg z-10 hover:bg-gray-100 transition-colors duration-300"
                >
                  <X className="h-6 w-6" />
                </button>
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  className="w-full h-80 object-cover"
                />
              </div>
              <div className="p-8">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-3xl font-bold text-gray-900">{selectedProduct.name}</h3>
                  <span className="text-3xl font-bold text-pink-600">{selectedProduct.price}</span>
                </div>
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < selectedProduct.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                      }`}
                    />
                  ))}
                  <span className="ml-2 text-gray-600">({selectedProduct.rating}.0 rating)</span>
                </div>
                <p className="text-gray-600 mb-6">{selectedProduct.description}</p>
                <div className="mb-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-3">Features:</h4>
                  <ul className="space-y-2">
                    {selectedProduct.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-gray-600">
                        <div className="w-2 h-2 bg-pink-500 rounded-full mr-3"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex space-x-4">
                  <button className="flex-1 bg-pink-600 hover:bg-pink-700 text-white py-4 rounded-full font-semibold transition-colors duration-300 flex items-center justify-center space-x-2">
                    <ShoppingCart className="h-5 w-5" />
                    <span>Add to Cart</span>
                  </button>
                  <button 
                    onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                    className="flex-1 border-2 border-pink-600 text-pink-600 hover:bg-pink-600 hover:text-white py-4 rounded-full font-semibold transition-all duration-300"
                  >
                    Custom Order
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Products;