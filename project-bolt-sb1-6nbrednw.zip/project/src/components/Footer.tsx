import React from 'react';
import { Cake, Facebook, Instagram, Twitter, Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Cake className="h-8 w-8 text-pink-500" />
              <span className="font-bold text-xl">Sweet Dreams</span>
            </div>
            <p className="text-gray-400 mb-4">
              Creating magical moments through exceptional cakes since 1995. 
              Every bite is a celebration of life's sweetest moments.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors duration-300">
                <Facebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors duration-300">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors duration-300">
                <Twitter className="h-6 w-6" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-400 hover:text-pink-500 transition-colors duration-300">Home</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-pink-500 transition-colors duration-300">About Us</a></li>
              <li><a href="#products" className="text-gray-400 hover:text-pink-500 transition-colors duration-300">Products</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-pink-500 transition-colors duration-300">Contact</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Our Services</h4>
            <ul className="space-y-2">
              <li><span className="text-gray-400">Wedding Cakes</span></li>
              <li><span className="text-gray-400">Birthday Cakes</span></li>
              <li><span className="text-gray-400">Custom Designs</span></li>
              <li><span className="text-gray-400">Cupcakes & Treats</span></li>
              <li><span className="text-gray-400">Catering Services</span></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Contact Info</h4>
            <div className="space-y-2 text-gray-400">
              <p>123 Sweet Street</p>
              <p>Bakery District, BD 12345</p>
              <p>Phone: +1 (555) 123-CAKE</p>
              <p>Email: info@sweetdreams.com</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2025 Sweet Dreams Bakery. All rights reserved.
          </p>
          <p className="text-gray-400 text-sm flex items-center mt-4 md:mt-0">
            Made with <Heart className="h-4 w-4 text-pink-500 mx-1" /> by Sweet Dreams Team
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;